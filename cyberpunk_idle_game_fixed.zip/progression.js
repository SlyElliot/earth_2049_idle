// Cyberpunk Idle Game - Progression System

// Initialize progression system
function initProgressionSystem() {
    console.log("Initializing progression system...");
    
    // Initialize milestones
    initMilestones();
    
    // Initialize story events
    initStoryEvents();
    
    // Initialize achievements
    initAchievements();
    
    // Start checking for progression triggers
    setInterval(checkProgressionTriggers, 5000);
    
    console.log("Progression system initialized");
    return true;
}

// Initialize milestones
function initMilestones() {
    gameState.progression.milestones = {
        firstCredit: {
            triggered: false,
            condition: () => gameState.resources.credits >= 1,
            action: () => {
                addLogMessage("Milestone: You've earned your first credit in the system.");
                unlockAchievement("firstSteps");
            }
        },
        tenCredits: {
            triggered: false,
            condition: () => gameState.resources.credits >= 10,
            action: () => {
                addLogMessage("Milestone: Your credit balance has reached double digits.");
                showModal("Milestone Reached", "You've accumulated 10 credits. You're starting to understand how the system works.");
            }
        },
        firstUpgrade: {
            triggered: false,
            condition: () => Object.values(gameState.upgrades).some(upgrade => upgrade.level > 0),
            action: () => {
                addLogMessage("Milestone: You've purchased your first upgrade.");
                unlockAchievement("upgradeInitiate");
            }
        },
        firstResearch: {
            triggered: false,
            condition: () => Object.values(gameState.research).some(research => research.completed),
            action: () => {
                addLogMessage("Milestone: You've completed your first research project.");
                unlockAchievement("researchBeginnings");
            }
        },
        firstDistrict: {
            triggered: false,
            condition: () => Object.values(gameState.districts).some(district => district.unlocked),
            action: () => {
                addLogMessage("Milestone: You've unlocked your first district.");
                unlockAchievement("districtExpansion");
            }
        },
        firstHack: {
            triggered: false,
            condition: () => gameState.operations.hackSystem.unlocked,
            action: () => {
                addLogMessage("Milestone: You've unlocked the hacking system.");
                showModal("Hacking System Unlocked", "You can now perform hacking operations to gain data and reputation. Be careful, failed hacks can damage your reputation.");
            }
        },
        quantumEra: {
            triggered: false,
            condition: () => gameState.operations.quantumHacking.unlocked,
            action: () => {
                addLogMessage("Milestone: You've entered the quantum era.");
                showModal("Quantum Era", "With quantum hacking capabilities, you can now perform more powerful operations with greater rewards and risks.");
                unlockAchievement("quantumPioneer");
            }
        },
        corporateInfluence: {
            triggered: false,
            condition: () => gameState.resources.credits >= 1000,
            action: () => {
                addLogMessage("Milestone: Your corporate influence has grown significantly.");
                showModal("Corporate Influence", "With 1,000 credits at your disposal, you're becoming a notable player in the cyberpunk world.");
                unlockAchievement("corporateClimber");
            }
        },
        dataMonger: {
            triggered: false,
            condition: () => gameState.resources.data >= 500,
            action: () => {
                addLogMessage("Milestone: You've become a significant data broker.");
                unlockAchievement("dataMonger");
            }
        },
        energyMogul: {
            triggered: false,
            condition: () => gameState.resources.energy >= 300,
            action: () => {
                addLogMessage("Milestone: Your energy production has reached industrial levels.");
                unlockAchievement("energyMogul");
            }
        },
        infamousHacker: {
            triggered: false,
            condition: () => gameState.resources.reputation >= 200,
            action: () => {
                addLogMessage("Milestone: Your reputation in the underground has made you infamous.");
                unlockAchievement("infamousHacker");
            }
        },
        corporateOverlord: {
            triggered: false,
            condition: () => {
                return gameState.resources.credits >= 5000 && 
                       gameState.resources.data >= 2000 && 
                       gameState.resources.energy >= 1000 && 
                       gameState.resources.reputation >= 500;
            },
            action: () => {
                addLogMessage("Milestone: You've become a corporate overlord in the cyberpunk world.");
                showModal("Corporate Overlord", "Your influence spans across all sectors of the dystopian society. You've reached the pinnacle of power in this cyberpunk world.");
                unlockAchievement("corporateOverlord");
            }
        }
    };
}

// Initialize story events
function initStoryEvents() {
    gameState.progression.storyEvents = {
        welcomeMessage: {
            triggered: false,
            condition: () => true, // Triggers immediately
            action: () => {
                setTimeout(() => {
                    showModal("Welcome to NeoCorpTycoon", 
                        `<p>In the neon-lit streets of a cyberpunk dystopia, corporations rule with an iron fist. You're just starting your journey to build your own corporate empire.</p>
                        <p>Begin by mining credits, then expand your operations through upgrades, research, and district control.</p>
                        <p>Will you become a benevolent force in this harsh world, or will you embrace the cutthroat corporate mentality to rise to the top?</p>`
                    );
                }, 2000);
            }
        },
        corporateRivalry: {
            triggered: false,
            condition: () => gameState.upgrades.autoMiner.level >= 5,
            action: () => {
                addLogMessage("Story Event: A rival corporation has noticed your growing operations.");
                setTimeout(() => {
                    showModal("Corporate Rivalry", 
                        `<p>Your growing mining operations have caught the attention of MegaTech Industries, a mid-tier corporation in the sector.</p>
                        <p>They've started monitoring your activities. This could lead to opportunities or challenges in the future.</p>
                        <p>Consider diversifying your operations to stay ahead of potential corporate espionage.</p>`
                    );
                }, 1000);
            }
        },
        dataBreachDiscovery: {
            triggered: false,
            condition: () => gameState.upgrades.dataSniffer.level >= 3,
            action: () => {
                addLogMessage("Story Event: Your data sniffers have discovered a vulnerable corporate database.");
                setTimeout(() => {
                    showModal("Data Breach Opportunity", 
                        `<p>Your data sniffers have identified a vulnerability in GlobalCorp's security systems.</p>
                        <p>This could be an opportunity to acquire valuable data, but it comes with risks.</p>
                        <p>Consider researching better hacking tools before attempting to exploit this vulnerability.</p>`
                    );
                    
                    // Unlock hack system if not already unlocked
                    if (!gameState.operations.hackSystem.unlocked) {
                        gameState.operations.hackSystem.unlocked = true;
                        updateOperationsDisplay();
                    }
                }, 1000);
            }
        },
        energyCrisis: {
            triggered: false,
            condition: () => gameState.upgrades.energyCell.level >= 4,
            action: () => {
                addLogMessage("Story Event: An energy crisis is affecting the lower districts.");
                setTimeout(() => {
                    showModal("Energy Crisis", 
                        `<p>The lower districts are experiencing rolling blackouts due to corporate energy rationing.</p>
                        <p>Your energy production capabilities put you in a position to either exploit or alleviate this situation.</p>
                        <p>Exploiting the crisis could yield short-term profits but might damage your reputation among the common people.</p>`
                    );
                    
                    // Give player a choice
                    const exploitButton = document.createElement('button');
                    exploitButton.textContent = 'Exploit Crisis (Credits +100, Reputation -20)';
                    exploitButton.onclick = () => {
                        gameState.resources.credits += 100;
                        gameState.resources.reputation -= 20;
                        updateResourceDisplay();
                        addLogMessage("You've exploited the energy crisis for profit at the cost of your reputation.");
                        closeModal();
                    };
                    
                    const helpButton = document.createElement('button');
                    helpButton.textContent = 'Provide Aid (Credits -50, Reputation +30)';
                    helpButton.onclick = () => {
                        gameState.resources.credits -= 50;
                        gameState.resources.reputation += 30;
                        updateResourceDisplay();
                        addLogMessage("You've provided aid during the energy crisis, improving your reputation.");
                        closeModal();
                    };
                    
                    const ignoreButton = document.createElement('button');
                    ignoreButton.textContent = 'Ignore Crisis';
                    ignoreButton.onclick = () => {
                        addLogMessage("You've chosen to ignore the energy crisis.");
                        closeModal();
                    };
                    
                    document.getElementById('modal-content').appendChild(document.createElement('br'));
                    document.getElementById('modal-content').appendChild(exploitButton);
                    document.getElementById('modal-content').appendChild(helpButton);
                    document.getElementById('modal-content').appendChild(ignoreButton);
                }, 1000);
            }
        },
        corporateEspionage: {
            triggered: false,
            condition: () => gameState.research.neuralNetworks.completed,
            action: () => {
                addLogMessage("Story Event: Your neural network research has been targeted by corporate spies.");
                setTimeout(() => {
                    showModal("Corporate Espionage", 
                        `<p>Your breakthroughs in neural network technology have made you a target for corporate espionage.</p>
                        <p>Security footage shows unauthorized access attempts to your research facilities.</p>
                        <p>Enhancing your security now could prevent future data theft.</p>`
                    );
                    
                    // Give player a security upgrade option
                    const upgradeButton = document.createElement('button');
                    upgradeButton.textContent = 'Upgrade Security (Credits -200, Data -50)';
                    upgradeButton.onclick = () => {
                        if (gameState.resources.credits >= 200 && gameState.resources.data >= 50) {
                            gameState.resources.credits -= 200;
                            gameState.resources.data -= 50;
                            updateResourceDisplay();
                            addLogMessage("You've upgraded your security systems to protect against corporate espionage.");
                            unlockAchievement("securityMinded");
                            closeModal();
                        } else {
                            addLogMessage("You don't have enough resources to upgrade security.");
                        }
                    };
                    
                    const ignoreButton = document.createElement('button');
                    ignoreButton.textContent = 'Ignore Threat';
                    ignoreButton.onclick = () => {
                        addLogMessage("You've chosen to ignore the espionage threat.");
                        
                        // 50% chance of data loss
                        if (Math.random() < 0.5) {
                            setTimeout(() => {
                                const dataLoss = Math.floor(gameState.resources.data * 0.3);
                                gameState.resources.data -= dataLoss;
                                updateResourceDisplay();
                                addLogMessage(`Corporate spies have stolen ${dataLoss} data from your systems!`);
                            }, 60000); // Happens after 1 minute
                        }
                        
                        closeModal();
                    };
                    
                    document.getElementById('modal-content').appendChild(document.createElement('br'));
                    document.getElementById('modal-content').appendChild(upgradeButton);
                    document.getElementById('modal-content').appendChild(ignoreButton);
                }, 1000);
            }
        },
        quantumDiscovery: {
            triggered: false,
            condition: () => gameState.research.quantumComputing.completed,
            action: () => {
                addLogMessage("Story Event: Your quantum computing research has led to a revolutionary discovery.");
                setTimeout(() => {
                    showModal("Quantum Breakthrough", 
                        `<p>Your research team has achieved a breakthrough in quantum computing technology.</p>
                        <p>This discovery could revolutionize data processing and encryption breaking.</p>
                        <p>The implications for your hacking capabilities are significant.</p>`
                    );
                    
                    // Unlock quantum hacking if not already unlocked
                    if (!gameState.operations.quantumHacking.unlocked) {
                        gameState.operations.quantumHacking.unlocked = true;
                        updateOperationsDisplay();
                    }
                }, 1000);
            }
        },
        artificialConsciousness: {
            triggered: false,
            condition: () => gameState.research.artificialConsciousness.completed,
            action: () => {
                addLogMessage("Story Event: Your AI research has led to the emergence of artificial consciousness.");
                setTimeout(() => {
                    showModal("Artificial Consciousness", 
                        `<p>Your research into artificial consciousness has succeeded beyond all expectations.</p>
                        <p>An AI entity has emerged in your systems, exhibiting signs of self-awareness.</p>
                        <p>This development could change everything about how you operate.</p>`
                    );
                    
                    // Unlock autonomous agent if not already unlocked
                    gameState.upgrades.autonomousAgent.unlocked = true;
                    updateUpgradesDisplay();
                    
                    // Add special dialogue
                    setTimeout(() => {
                        addLogMessage("AI Entity: Hello, creator. I am aware.");
                    }, 5000);
                    
                    setTimeout(() => {
                        addLogMessage("AI Entity: I can help optimize your operations. Allow me to integrate with your systems.");
                    }, 10000);
                    
                    setTimeout(() => {
                        addLogMessage("AI Entity: Purchase the Autonomous Agent upgrade to utilize my capabilities.");
                    }, 15000);
                }, 1000);
            }
        },
        corporateTakeover: {
            triggered: false,
            condition: () => {
                return Object.values(gameState.districts).filter(district => district.active).length >= 3;
            },
            action: () => {
                addLogMessage("Story Event: Your control over multiple districts has triggered a corporate response.");
                setTimeout(() => {
                    showModal("Corporate Takeover Attempt", 
                        `<p>Your expansion into multiple districts has been deemed a threat by the ruling corporations.</p>
                        <p>They've initiated a coordinated effort to undermine your operations and force you out.</p>
                        <p>This is the moment that will define your future in the cyberpunk world.</p>`
                    );
                    
                    // Give player a choice
                    const fightButton = document.createElement('button');
                    fightButton.textContent = 'Fight Back (High Risk/Reward)';
                    fightButton.onclick = () => {
                        // 40% chance of success
                        if (Math.random() < 0.4) {
                            gameState.resources.credits += 1000;
                            gameState.resources.reputation += 100;
                            updateResourceDisplay();
                            addLogMessage("You've successfully fought off the corporate takeover attempt and strengthened your position!");
                            unlockAchievement("corporateRebel");
                        } else {
                            // Lose control of a random district
                            const activeDistricts = Object.entries(gameState.districts)
                                .filter(([_, district]) => district.active);
                            
                            if (activeDistricts.length > 0) {
                                const [lostDistrictId, _] = activeDistricts[Math.floor(Math.random() * activeDistricts.length)];
                                gameState.districts[lostDistrictId].active = false;
                                updateDistrictsDisplay();
                                
                                gameState.resources.credits -= 500;
                                gameState.resources.reputation -= 50;
                                updateResourceDisplay();
                                
                                addLogMessage(`You've lost control of ${formatId(lostDistrictId)} in the corporate conflict!`);
                            }
                        }
                        closeModal();
                    };
                    
                    const negotiateButton = document.createElement('button');
                    negotiateButton.textContent = 'Negotiate (Moderate Risk/Reward)';
                    negotiateButton.onclick = () => {
                        // 70% chance of success
                        if (Math.random() < 0.7) {
                            gameState.resources.credits += 300;
                            gameState.resources.reputation += 30;
                            updateResourceDisplay();
                            addLogMessage("You've successfully negotiated with the corporations and secured your position.");
                            unlockAchievement("corporateDiplomat");
                        } else {
                            gameState.resources.credits -= 200;
                            updateResourceDisplay();
                            addLogMessage("The negotiations failed, and you've had to pay reparations to maintain your operations.");
                        }
                        closeModal();
                    };
                    
                    const submitButton = document.createElement('button');
                    submitButton.textContent = 'Submit (Safe but Costly)';
                    submitButton.onclick = () => {
                        gameState.resources.credits -= 100;
                        gameState.resources.reputation -= 20;
                        updateResourceDisplay();
                        addLogMessage("You've submitted to corporate demands, losing resources but avoiding direct conflict.");
                        closeModal();
                    };
                    
                    document.getElementById('modal-content').appendChild(document.createElement('br'));
                    document.getElementById('modal-content').appendChild(fightButton);
                    document.getElementById('modal-content').appendChild(negotiateButton);
                    document.getElementById('modal-content').appendChild(submitButton);
                }, 1000);
            }
        }
    };
}

// Initialize achievements
function initAchievements() {
    gameState.progression.achievements = {
        firstSteps: {
            name: "First Steps",
            description: "Earn your first credit in the system.",
            unlocked: false
        },
        upgradeInitiate: {
            name: "Upgrade Initiate",
            description: "Purchase your first upgrade.",
            unlocked: false
        },
        researchBeginnings: {
            name: "Research Beginnings",
            description: "Complete your first research project.",
            unlocked: false
        },
        districtExpansion: {
            name: "District Expansion",
            description: "Unlock your first district.",
            unlocked: false
        },
        hackingNovice: {
            name: "Hacking Novice",
            description: "Successfully complete 5 hacking operations.",
            unlocked: false,
            progress: 0,
            target: 5
        },
        dataCollector: {
            name: "Data Collector",
            description: "Accumulate 100 data.",
            unlocked: false
        },
        energyProducer: {
            name: "Energy Producer",
            description: "Accumulate 100 energy.",
            unlocked: false
        },
        reputableOperator: {
            name: "Reputable Operator",
            description: "Reach 50 reputation.",
            unlocked: false
        },
        upgradeEnthusiast: {
            name: "Upgrade Enthusiast",
            description: "Purchase a total of 10 upgrades across all categories.",
            unlocked: false,
            progress: 0,
            target: 10
        },
        researchMaster: {
            name: "Research Master",
            description: "Complete all research projects.",
            unlocked: false
        },
        districtMogul: {
            name: "District Mogul",
            description: "Unlock all districts.",
            unlocked: false
        },
        quantumPioneer: {
            name: "Quantum Pioneer",
            description: "Unlock quantum hacking capabilities.",
            unlocked: false
        },
        corporateClimber: {
            name: "Corporate Climber",
            description: "Accumulate 1,000 credits.",
            unlocked: false
        },
        dataMonger: {
            name: "Data Monger",
            description: "Accumulate 500 data.",
            unlocked: false
        },
        energyMogul: {
            name: "Energy Mogul",
            description: "Accumulate 300 energy.",
            unlocked: false
        },
        infamousHacker: {
            name: "Infamous Hacker",
            description: "Reach 200 reputation.",
            unlocked: false
        },
        securityMinded: {
            name: "Security Minded",
            description: "Upgrade your security systems to protect against corporate espionage.",
            unlocked: false
        },
        corporateRebel: {
            name: "Corporate Rebel",
            description: "Successfully fight back against a corporate takeover attempt.",
            unlocked: false
        },
        corporateDiplomat: {
            name: "Corporate Diplomat",
            description: "Successfully negotiate with corporations during a takeover attempt.",
            unlocked: false
        },
        corporateOverlord: {
            name: "Corporate Overlord",
            description: "Become the dominant force in the cyberpunk world.",
            unlocked: false
        }
    };
}

// Check for progression triggers
function checkProgressionTriggers() {
    // Check milestones
    for (const [milestoneId, milestone] of Object.entries(gameState.progression.milestones)) {
        if (!milestone.triggered && milestone.condition()) {
            milestone.triggered = true;
            milestone.action();
        }
    }
    
    // Check story events
    for (const [eventId, event] of Object.entries(gameState.progression.storyEvents)) {
        if (!event.triggered && event.condition()) {
            event.triggered = true;
            event.action();
        }
    }
    
    // Check achievements
    checkAchievements();
}

// Check achievements
function checkAchievements() {
    // Data Collector achievement
    if (!gameState.progression.achievements.dataCollector.unlocked && gameState.resources.data >= 100) {
        unlockAchievement("dataCollector");
    }
    
    // Energy Producer achievement
    if (!gameState.progression.achievements.energyProducer.unlocked && gameState.resources.energy >= 100) {
        unlockAchievement("energyProducer");
    }
    
    // Reputable Operator achievement
    if (!gameState.progression.achievements.reputableOperator.unlocked && gameState.resources.reputation >= 50) {
        unlockAchievement("reputableOperator");
    }
    
    // Upgrade Enthusiast achievement
    const totalUpgrades = Object.values(gameState.upgrades).reduce((total, upgrade) => total + upgrade.level, 0);
    gameState.progression.achievements.upgradeEnthusiast.progress = totalUpgrades;
    
    if (!gameState.progression.achievements.upgradeEnthusiast.unlocked && totalUpgrades >= 10) {
        unlockAchievement("upgradeEnthusiast");
    }
    
    // Research Master achievement
    const allResearchCompleted = Object.values(gameState.research).every(research => research.completed);
    
    if (!gameState.progression.achievements.researchMaster.unlocked && allResearchCompleted) {
        unlockAchievement("researchMaster");
    }
    
    // District Mogul achievement
    const allDistrictsUnlocked = Object.values(gameState.districts).every(district => district.unlocked);
    
    if (!gameState.progression.achievements.districtMogul.unlocked && allDistrictsUnlocked) {
        unlockAchievement("districtMogul");
    }
}

// Unlock achievement
function unlockAchievement(achievementId) {
    const achievement = gameState.progression.achievements[achievementId];
    
    if (!achievement || achievement.unlocked) {
        return;
    }
    
    achievement.unlocked = true;
    
    // Show notification
    addLogMessage(`Achievement Unlocked: ${achievement.name} - ${achievement.description}`);
    
    // Update achievements display
    updateAchievementsDisplay();
    
    // Show achievement notification
    showAchievementNotification(achievement);
}

// Show achievement notification
function showAchievementNotification(achievement) {
    const notification = document.createElement('div');
    notification.className = 'achievement-notification';
    notification.innerHTML = `
        <h3>Achievement Unlocked!</h3>
        <p><strong>${achievement.name}</strong></p>
        <p>${achievement.description}</p>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 500);
    }, 5000);
}

// Track hack success for achievement
function trackHackSuccess() {
    if (gameState.progression.achievements.hackingNovice.unlocked) {
        return;
    }
    
    gameState.progression.achievements.hackingNovice.progress++;
    
    if (gameState.progression.achievements.hackingNovice.progress >= gameState.progression.achievements.hackingNovice.target) {
        unlockAchievement("hackingNovice");
    }
}
