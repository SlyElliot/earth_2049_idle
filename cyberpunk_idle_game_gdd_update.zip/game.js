// Cyberpunk Idle Game - Main JavaScript

// Game state
let gameState = {
    // Resources
    resources: {
        credits: 0,
        data: 0,
        energy: 0,
        reputation: 0
    },
    
    // Resource generation rates (per second)
    rates: {
        credits: 0,
        data: 0,
        energy: 0,
        reputation: 0
    },
    
    // Upgrades
    upgrades: {
        autoMiner: {
            level: 0,
            baseCost: 10,
            costMultiplier: 1.15,
            baseEffect: 0.1,
            effectMultiplier: 1.1
        },
        dataSniffer: {
            level: 0,
            baseCost: 25,
            costMultiplier: 1.15,
            baseEffect: 0.05,
            effectMultiplier: 1.12
        },
        energyCell: {
            level: 0,
            baseCost: 50,
            costMultiplier: 1.2,
            baseEffect: 0.03,
            effectMultiplier: 1.15
        },
        botnet: {
            level: 0,
            baseCost: 100,
            costMultiplier: 1.25,
            baseEffect: 0.02,
            effectMultiplier: 1.2
        },
        autonomousAgent: {
            level: 0,
            baseCost: 1000,
            costMultiplier: 1.5,
            baseEffect: 0.5,
            effectMultiplier: 1.3,
            unlocked: false
        }
    },
    
    // Research
    research: {
        basicAlgorithms: {
            completed: false,
            cost: { credits: 50, data: 20 },
            unlocks: ["dataSniffer"]
        },
        neuralNetworks: {
            completed: false,
            cost: { credits: 200, data: 100, energy: 50 },
            unlocks: ["botnet"],
            requires: ["basicAlgorithms"]
        },
        quantumComputing: {
            completed: false,
            cost: { credits: 500, data: 250, energy: 150 },
            unlocks: ["quantumHacking"],
            requires: ["neuralNetworks"]
        },
        artificialConsciousness: {
            completed: false,
            cost: { credits: 2000, data: 1000, energy: 500, reputation: 100 },
            unlocks: ["autonomousAgent"],
            requires: ["quantumComputing"]
        }
    },
    
    // Districts
    districts: {
        industrialZone: {
            unlocked: false,
            cost: { credits: 300, energy: 100 },
            active: false,
            effect: { energy: 0.5, credits: 0.2 }
        },
        corporateSector: {
            unlocked: false,
            cost: { credits: 800, data: 200, reputation: 50 },
            active: false,
            effect: { credits: 0.5, reputation: 0.1 },
            requires: ["industrialZone"]
        },
        researchPark: {
            unlocked: false,
            cost: { credits: 1500, data: 500, energy: 300 },
            active: false,
            effect: { data: 0.5, energy: 0.2 },
            requires: ["corporateSector"]
        },
        blackMarket: {
            unlocked: false,
            cost: { credits: 3000, data: 1000, reputation: 200 },
            active: false,
            effect: { credits: 1.0, data: 0.5, reputation: -0.1 },
            requires: ["researchPark"]
        }
    },
    
    // Operations
    operations: {
        hackSystem: {
            unlocked: false,
            cooldown: 0,
            baseSuccessRate: 0.7,
            baseReward: { data: 5, reputation: 1 },
            basePenalty: { reputation: -2 }
        },
        quantumHacking: {
            unlocked: false,
            cooldown: 0,
            baseSuccessRate: 0.5,
            baseReward: { data: 20, energy: 10, reputation: 5 },
            basePenalty: { energy: -15, reputation: -10 }
        }
    },
    
    // Game progression
    progression: {
        milestones: {},
        storyEvents: {},
        achievements: {}
    },
    
    // Settings
    settings: {
        lastSaveTime: Date.now(),
        darkMode: true,
        soundEnabled: true
    }
};

// Initialize game
function initGame() {
    console.log("Initializing Cyberpunk Idle Game...");
    
    // Load saved game if exists
    loadGame();
    
    // Initialize UI
    updateResourceDisplay();
    updateUpgradesDisplay();
    updateResearchDisplay();
    updateDistrictsDisplay();
    updateOperationsDisplay();
    updateAchievementsDisplay();
    
    // Start game loops
    setInterval(gameLoop, 1000);
    setInterval(saveGame, 30000);
    
    // Initialize progression system
    initProgressionSystem();
    
    // Make sure all functions are properly exposed to the global scope
    window.unlockDistrict = unlockDistrict;
    window.activateDistrict = activateDistrict;
    window.buyUpgrade = buyUpgrade;
    window.conductResearch = conductResearch;
    window.hackSystem = hackSystem;
    window.quantumHack = quantumHack;
    window.switchTab = switchTab;
    window.toggleAchievements = toggleAchievements;
    
    // Add initial log message
    addLogMessage("System booted. Welcome to NeoCorpTycoon.");
    
    console.log("Game initialized successfully.");
}

// Main game loop (runs every second)
function gameLoop() {
    // Update resources based on rates
    updateResources();
    
    // Update UI
    updateResourceDisplay();
    
    // Check for milestones and events
    checkProgressionTriggers();
    
    // Update cooldowns
    updateCooldowns();
}

// Update resources based on current rates
function updateResources() {
    gameState.resources.credits += gameState.rates.credits;
    gameState.resources.data += gameState.rates.data;
    gameState.resources.energy += gameState.rates.energy;
    gameState.resources.reputation += gameState.rates.reputation;
    
    // Round resources to 2 decimal places
    gameState.resources.credits = Math.round(gameState.resources.credits * 100) / 100;
    gameState.resources.data = Math.round(gameState.resources.data * 100) / 100;
    gameState.resources.energy = Math.round(gameState.resources.energy * 100) / 100;
    gameState.resources.reputation = Math.round(gameState.resources.reputation * 100) / 100;
    
    return true; // For testing purposes
}

// Update cooldowns for operations
function updateCooldowns() {
    if (gameState.operations.hackSystem.cooldown > 0) {
        gameState.operations.hackSystem.cooldown--;
        updateOperationCooldownDisplay('hackSystem');
    }
    
    if (gameState.operations.quantumHacking.cooldown > 0) {
        gameState.operations.quantumHacking.cooldown--;
        updateOperationCooldownDisplay('quantumHacking');
    }
}

// Update operation cooldown display
function updateOperationCooldownDisplay(operationId) {
    const cooldownElement = document.getElementById(`${operationId}-cooldown`);
    if (cooldownElement) {
        const cooldown = gameState.operations[operationId].cooldown;
        if (cooldown > 0) {
            cooldownElement.textContent = `Cooldown: ${cooldown}s`;
            cooldownElement.style.display = 'block';
        } else {
            cooldownElement.style.display = 'none';
        }
    }
}

// Manual operations
function mineCredits() {
    gameState.resources.credits += 1;
    updateResourceDisplay();
    createParticles('credits-value', '+1', 'credit-particle');
    return true; // For testing purposes
}

function collectData() {
    if (gameState.resources.credits >= 5) {
        gameState.resources.credits -= 5;
        gameState.resources.data += 1;
        updateResourceDisplay();
        createParticles('data-value', '+1', 'data-particle');
        return true; // For testing purposes
    }
    return false;
}

function generateEnergy() {
    if (gameState.resources.credits >= 10) {
        gameState.resources.credits -= 10;
        gameState.resources.energy += 1;
        updateResourceDisplay();
        createParticles('energy-value', '+1', 'energy-particle');
        return true;
    }
    return false;
}

function hackSystem() {
    // Check if on cooldown
    if (gameState.operations.hackSystem.cooldown > 0) {
        addLogMessage(`Hack System operation is on cooldown. ${gameState.operations.hackSystem.cooldown}s remaining.`);
        return false;
    }
    
    // Set cooldown
    gameState.operations.hackSystem.cooldown = 10; // 10 seconds cooldown
    updateOperationCooldownDisplay('hackSystem');
    
    // Disable the button during cooldown
    const hackButtons = document.querySelectorAll('button[onclick="hackSystem()"]');
    hackButtons.forEach(button => {
        button.disabled = true;
        setTimeout(() => {
            button.disabled = false;
        }, gameState.operations.hackSystem.cooldown * 1000);
    });
    
    // Determine success based on success rate
    const success = Math.random() < gameState.operations.hackSystem.baseSuccessRate;
    
    if (success) {
        // Apply rewards
        gameState.resources.data += gameState.operations.hackSystem.baseReward.data;
        gameState.resources.reputation += gameState.operations.hackSystem.baseReward.reputation;
        
        // Update UI
        updateResourceDisplay();
        createParticles('data-value', `+${gameState.operations.hackSystem.baseReward.data}`, 'data-particle');
        createParticles('reputation-value', `+${gameState.operations.hackSystem.baseReward.reputation}`, 'reputation-particle');
        
        // Log success
        addLogMessage("Hack successful. Data acquired.");
        return true;
    } else {
        // Apply penalty
        gameState.resources.reputation += gameState.operations.hackSystem.basePenalty.reputation;
        
        // Update UI
        updateResourceDisplay();
        createParticles('reputation-value', gameState.operations.hackSystem.basePenalty.reputation, 'reputation-particle');
        
        // Set shorter cooldown for failed attempts
        gameState.operations.hackSystem.cooldown = 5; // 5 seconds cooldown for failed attempts
        updateOperationCooldownDisplay('hackSystem');
        
        // Update button disabled time for failed attempts
        hackButtons.forEach(button => {
            setTimeout(() => {
                button.disabled = false;
            }, 5000); // 5 seconds for failed attempts
        });
        
        // Log failure
        addLogMessage("Hack failed. Security alerted.");
        return false;
    }
}

function quantumHack() {
    // Check if on cooldown
    if (gameState.operations.quantumHacking.cooldown > 0) {
        addLogMessage(`Quantum Hacking operation is on cooldown. ${gameState.operations.quantumHacking.cooldown}s remaining.`);
        return false;
    }
    
    // Set cooldown
    gameState.operations.quantumHacking.cooldown = 30; // 30 seconds cooldown
    updateOperationCooldownDisplay('quantumHacking');
    
    // Disable the button during cooldown
    const hackButtons = document.querySelectorAll('button[onclick="quantumHack()"]');
    hackButtons.forEach(button => {
        button.disabled = true;
        setTimeout(() => {
            button.disabled = false;
        }, gameState.operations.quantumHacking.cooldown * 1000);
    });
    
    // Determine success based on success rate
    const success = Math.random() < gameState.operations.quantumHacking.baseSuccessRate;
    
    if (success) {
        // Apply rewards
        gameState.resources.data += gameState.operations.quantumHacking.baseReward.data;
        gameState.resources.energy += gameState.operations.quantumHacking.baseReward.energy;
        gameState.resources.reputation += gameState.operations.quantumHacking.baseReward.reputation;
        
        // Update UI
        updateResourceDisplay();
        createParticles('data-value', `+${gameState.operations.quantumHacking.baseReward.data}`, 'data-particle');
        createParticles('energy-value', `+${gameState.operations.quantumHacking.baseReward.energy}`, 'energy-particle');
        createParticles('reputation-value', `+${gameState.operations.quantumHacking.baseReward.reputation}`, 'reputation-particle');
        
        // Log success
        addLogMessage("Quantum hack successful. Significant data breach achieved.");
        return true;
    } else {
        // Apply penalty
        gameState.resources.energy += gameState.operations.quantumHacking.basePenalty.energy;
        gameState.resources.reputation += gameState.operations.quantumHacking.basePenalty.reputation;
        
        // Update UI
        updateResourceDisplay();
        createParticles('energy-value', gameState.operations.quantumHacking.basePenalty.energy, 'energy-particle');
        createParticles('reputation-value', gameState.operations.quantumHacking.basePenalty.reputation, 'reputation-particle');
        
        // Log failure
        addLogMessage("Quantum hack failed. Energy systems damaged and reputation decreased.");
        return false;
    }
}

// Upgrades
function buyUpgrade(upgradeId) {
    const upgrade = gameState.upgrades[upgradeId];
    
    // Special case for Autonomous Agent - allow purchase if it's the autonomousAgent upgrade and has base cost of 1000
    if (upgradeId === 'autonomousAgent') {
        // Auto-unlock if player has enough credits
        if (gameState.resources.credits >= 1000) {
            upgrade.unlocked = true;
        } else if (!upgrade.unlocked) {
            addLogMessage("Autonomous Agent is not yet unlocked. You need 1000 credits to unlock it.");
            return false;
        }
    }
    
    // Calculate cost
    const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.level));
    
    // Check if player has enough credits
    if (gameState.resources.credits >= cost) {
        // Purchase upgrade
        gameState.resources.credits -= cost;
        upgrade.level++;
        
        // Update rates
        updateRates();
        
        // Update UI
        updateResourceDisplay();
        updateUpgradesDisplay();
        
        // Special handling for autonomous agent
        if (upgradeId === 'autonomousAgent' && upgrade.level === 1) {
            startAutonomousAgentLoop();
            addLogMessage("Autonomous Agent activated. All resources now generate automatically.");
        } else {
            addLogMessage(`${upgradeId} upgraded to level ${upgrade.level}.`);
        }
        
        return true;
    } else {
        addLogMessage(`Not enough credits to purchase ${upgradeId} upgrade.`);
        return false;
    }
}

// Start autonomous agent loop
function startAutonomousAgentLoop() {
    // This function starts the autonomous agent functionality
    // It will automatically generate all resources at a base rate
    setInterval(() => {
        const baseRate = gameState.upgrades.autonomousAgent.baseEffect * 
                        Math.pow(gameState.upgrades.autonomousAgent.effectMultiplier, 
                                gameState.upgrades.autonomousAgent.level - 1);
        
        gameState.resources.credits += baseRate;
        gameState.resources.data += baseRate * 0.5;
        gameState.resources.energy += baseRate * 0.3;
        gameState.resources.reputation += baseRate * 0.1;
        
        updateResourceDisplay();
    }, 1000);
}

// Update rates based on upgrades and active districts
function updateRates() {
    // Reset rates
    gameState.rates.credits = 0;
    gameState.rates.data = 0;
    gameState.rates.energy = 0;
    gameState.rates.reputation = 0;
    
    // Apply upgrade effects
    if (gameState.upgrades.autoMiner.level > 0) {
        gameState.rates.credits += gameState.upgrades.autoMiner.baseEffect * 
                                  Math.pow(gameState.upgrades.autoMiner.effectMultiplier, 
                                          gameState.upgrades.autoMiner.level - 1);
    }
    
    if (gameState.upgrades.dataSniffer.level > 0) {
        gameState.rates.data += gameState.upgrades.dataSniffer.baseEffect * 
                               Math.pow(gameState.upgrades.dataSniffer.effectMultiplier, 
                                       gameState.upgrades.dataSniffer.level - 1);
    }
    
    if (gameState.upgrades.energyCell.level > 0) {
        gameState.rates.energy += gameState.upgrades.energyCell.baseEffect * 
                                 Math.pow(gameState.upgrades.energyCell.effectMultiplier, 
                                         gameState.upgrades.energyCell.level - 1);
    }
    
    if (gameState.upgrades.botnet.level > 0) {
        gameState.rates.reputation += gameState.upgrades.botnet.baseEffect * 
                                     Math.pow(gameState.upgrades.botnet.effectMultiplier, 
                                             gameState.upgrades.botnet.level - 1);
    }
    
    // Apply district effects
    for (const [districtId, district] of Object.entries(gameState.districts)) {
        if (district.active) {
            for (const [resource, multiplier] of Object.entries(district.effect)) {
                gameState.rates[resource] += gameState.rates[resource] * multiplier;
            }
        }
    }
    
    return true; // For testing purposes
}

// Research
function conductResearch(researchId) {
    const research = gameState.research[researchId];
    
    // Check if already completed
    if (research.completed) {
        addLogMessage(`${researchId} research has already been completed.`);
        return false;
    }
    
    // Check prerequisites
    if (research.requires) {
        for (const req of research.requires) {
            if (!gameState.research[req].completed) {
                addLogMessage(`${researchId} research requires ${req} to be completed first.`);
                return false;
            }
        }
    }
    
    // Check resources
    for (const [resource, amount] of Object.entries(research.cost)) {
        if (gameState.resources[resource] < amount) {
            addLogMessage(`Not enough ${resource} to conduct ${researchId} research.`);
            return false;
        }
    }
    
    // Deduct resources
    for (const [resource, amount] of Object.entries(research.cost)) {
        gameState.resources[resource] -= amount;
    }
    
    // Complete research
    research.completed = true;
    
    // Unlock related items
    for (const unlock of research.unlocks) {
        if (gameState.upgrades[unlock]) {
            gameState.upgrades[unlock].unlocked = true;
        } else if (gameState.operations[unlock]) {
            gameState.operations[unlock].unlocked = true;
        }
    }
    
    // Update UI
    updateResourceDisplay();
    updateResearchDisplay();
    updateUpgradesDisplay();
    updateOperationsDisplay();
    
    // Log completion
    addLogMessage(`${researchId} research completed successfully.`);
    
    return true;
}

// Districts
function unlockDistrict(districtId) {
    const district = gameState.districts[districtId];
    
    // Check if already unlocked
    if (district.unlocked) {
        addLogMessage(`${districtId} is already unlocked.`);
        return false;
    }
    
    // Check prerequisites
    if (district.requires) {
        for (const req of district.requires) {
            if (!gameState.districts[req].unlocked) {
                addLogMessage(`${districtId} requires ${req} to be unlocked first.`);
                return false;
            }
        }
    }
    
    // Check resources
    for (const [resource, amount] of Object.entries(district.cost)) {
        if (gameState.resources[resource] < amount) {
            addLogMessage(`Not enough ${resource} to unlock ${districtId}.`);
            return false;
        }
    }
    
    // Deduct resources
    for (const [resource, amount] of Object.entries(district.cost)) {
        gameState.resources[resource] -= amount;
    }
    
    // Unlock district
    district.unlocked = true;
    
    // Update UI
    updateResourceDisplay();
    updateDistrictsDisplay();
    
    // Log unlock
    addLogMessage(`${districtId} has been unlocked.`);
    
    return true;
}

function activateDistrict(districtId) {
    const district = gameState.districts[districtId];
    
    // Check if unlocked
    if (!district.unlocked) {
        addLogMessage(`${districtId} needs to be unlocked first.`);
        return false;
    }
    
    // Toggle active state
    district.active = !district.active;
    
    // Update rates
    updateRates();
    
    // Update UI
    updateDistrictsDisplay();
    
    // Log activation/deactivation
    if (district.active) {
        addLogMessage(`${districtId} has been activated.`);
    } else {
        addLogMessage(`${districtId} has been deactivated.`);
    }
    
    return true;
}

// Update UI displays
function updateResourceDisplay() {
    document.getElementById('credits-value').textContent = gameState.resources.credits.toFixed(1);
    document.getElementById('data-value').textContent = gameState.resources.data.toFixed(1);
    document.getElementById('energy-value').textContent = gameState.resources.energy.toFixed(1);
    document.getElementById('reputation-value').textContent = gameState.resources.reputation.toFixed(1);
    
    document.getElementById('credits-rate').textContent = gameState.rates.credits.toFixed(2) + '/s';
    document.getElementById('data-rate').textContent = gameState.rates.data.toFixed(2) + '/s';
    document.getElementById('energy-rate').textContent = gameState.rates.energy.toFixed(2) + '/s';
    document.getElementById('reputation-rate').textContent = gameState.rates.reputation.toFixed(2) + '/s';
}

function updateUpgradesDisplay() {
    const upgradesContainer = document.getElementById('upgrades-list');
    upgradesContainer.innerHTML = '';
    
    for (const [upgradeId, upgrade] of Object.entries(gameState.upgrades)) {
        // Skip if not unlocked and it's the autonomous agent
        if (upgradeId === 'autonomousAgent' && !upgrade.unlocked) {
            continue;
        }
        
        const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, upgrade.level));
        const effect = upgrade.baseEffect * Math.pow(upgrade.effectMultiplier, Math.max(1, upgrade.level));
        
        const upgradeElement = document.createElement('div');
        upgradeElement.className = 'upgrade-item';
        
        // Create elements individually instead of using innerHTML
        const heading = document.createElement('h3');
        heading.textContent = `${formatId(upgradeId)} (Level ${upgrade.level})`;
        
        const costPara = document.createElement('p');
        costPara.textContent = `Cost: ${cost} Credits`;
        
        const effectPara = document.createElement('p');
        effectPara.textContent = `Effect: +${effect.toFixed(2)} ${getUpgradeEffectType(upgradeId)}/s`;
        
        const button = document.createElement('button');
        button.textContent = 'Upgrade';
        if (gameState.resources.credits < cost) {
            button.disabled = true;
        }
        
        // Add direct event listener instead of using onclick attribute
        button.addEventListener('click', function() {
            buyUpgrade(upgradeId);
        });
        
        // Append all elements to the upgrade element
        upgradeElement.appendChild(heading);
        upgradeElement.appendChild(costPara);
        upgradeElement.appendChild(effectPara);
        upgradeElement.appendChild(button);
        
        upgradesContainer.appendChild(upgradeElement);
    }
}

function getUpgradeEffectType(upgradeId) {
    switch(upgradeId) {
        case 'autoMiner': return 'Credits';
        case 'dataSniffer': return 'Data';
        case 'energyCell': return 'Energy';
        case 'botnet': return 'Reputation';
        case 'autonomousAgent': return 'All Resources';
        default: return '';
    }
}

function updateResearchDisplay() {
    const researchContainer = document.getElementById('research-list');
    researchContainer.innerHTML = '';
    
    for (const [researchId, research] of Object.entries(gameState.research)) {
        // Check prerequisites
        let prerequisitesMet = true;
        if (research.requires) {
            for (const req of research.requires) {
                if (!gameState.research[req].completed) {
                    prerequisitesMet = false;
                    break;
                }
            }
        }
        
        // Skip if prerequisites not met
        if (!prerequisitesMet && !research.completed) {
            continue;
        }
        
        // Check resources
        let resourcesMet = true;
        let resourcesText = '';
        for (const [resource, amount] of Object.entries(research.cost)) {
            resourcesText += `${amount} ${formatId(resource)}, `;
            if (gameState.resources[resource] < amount) {
                resourcesMet = false;
            }
        }
        resourcesText = resourcesText.slice(0, -2); // Remove trailing comma and space
        
        const researchElement = document.createElement('div');
        researchElement.className = 'research-item';
        
        if (research.completed) {
            researchElement.innerHTML = `
                <h3>${formatId(researchId)} (Completed)</h3>
                <p>Unlocked: ${research.unlocks.map(u => formatId(u)).join(', ')}</p>
            `;
        } else {
            researchElement.innerHTML = `
                <h3>${formatId(researchId)}</h3>
                <p>Cost: ${resourcesText}</p>
                <p>Unlocks: ${research.unlocks.map(u => formatId(u)).join(', ')}</p>
                <button onclick="conductResearch('${researchId}')" ${!resourcesMet ? 'disabled' : ''}>
                    Research
                </button>
            `;
        }
        
        researchContainer.appendChild(researchElement);
    }
}

function updateDistrictsDisplay() {
    const districtsContainer = document.getElementById('districts-list');
    if (!districtsContainer) return; // Safety check
    
    districtsContainer.innerHTML = '';
    
    for (const [districtId, district] of Object.entries(gameState.districts)) {
        // Check prerequisites
        let prerequisitesMet = true;
        if (district.requires) {
            for (const req of district.requires) {
                if (!gameState.districts[req].unlocked) {
                    prerequisitesMet = false;
                    break;
                }
            }
        }
        
        // Skip if prerequisites not met and not unlocked
        if (!prerequisitesMet && !district.unlocked) {
            continue;
        }
        
        const districtElement = document.createElement('div');
        districtElement.className = 'district-item';
        
        if (district.unlocked) {
            // District effects text
            let effectsText = '';
            for (const [resource, multiplier] of Object.entries(district.effect)) {
                const sign = multiplier >= 0 ? '+' : '';
                effectsText += `${sign}${(multiplier * 100).toFixed(0)}% ${formatId(resource)}, `;
            }
            effectsText = effectsText.slice(0, -2); // Remove trailing comma and space
            
            // Create elements individually instead of using innerHTML
            const heading = document.createElement('h3');
            heading.textContent = formatId(districtId);
            
            const effectsPara = document.createElement('p');
            effectsPara.textContent = `Effects: ${effectsText}`;
            
            const button = document.createElement('button');
            button.textContent = district.active ? 'Deactivate' : 'Activate';
            if (district.active) {
                button.classList.add('active');
            }
            
            // Add direct event listener instead of using onclick attribute
            button.addEventListener('click', function() {
                activateDistrict(districtId);
            });
            
            // Append all elements to the district element
            districtElement.appendChild(heading);
            districtElement.appendChild(effectsPara);
            districtElement.appendChild(button);
        } else {
            // Resource cost text
            let costText = '';
            let resourcesMet = true;
            for (const [resource, amount] of Object.entries(district.cost)) {
                costText += `${amount} ${formatId(resource)}, `;
                if (gameState.resources[resource] < amount) {
                    resourcesMet = false;
                }
            }
            costText = costText.slice(0, -2); // Remove trailing comma and space
            
            // Create elements individually instead of using innerHTML
            const heading = document.createElement('h3');
            heading.textContent = formatId(districtId);
            
            const costPara = document.createElement('p');
            costPara.textContent = `Cost: ${costText}`;
            
            const button = document.createElement('button');
            button.textContent = 'Unlock';
            if (!resourcesMet) {
                button.disabled = true;
            }
            
            // Add direct event listener instead of using onclick attribute
            button.addEventListener('click', function() {
                unlockDistrict(districtId);
            });
            
            // Append all elements to the district element
            districtElement.appendChild(heading);
            districtElement.appendChild(costPara);
            districtElement.appendChild(button);
        }
        
        districtsContainer.appendChild(districtElement);
    }
    
    // Make sure the district functions are properly exposed to the global scope
    window.unlockDistrict = unlockDistrict;
    window.activateDistrict = activateDistrict;
}

function updateOperationsDisplay() {
    const operationsContainer = document.getElementById('operations-list');
    operationsContainer.innerHTML = '';
    
    // Hack System operation
    if (gameState.operations.hackSystem.unlocked) {
        const hackSystemElement = document.createElement('div');
        hackSystemElement.className = 'operation-item';
        hackSystemElement.innerHTML = `
            <h3>Hack System</h3>
            <p>Success Rate: ${(gameState.operations.hackSystem.baseSuccessRate * 100).toFixed(0)}%</p>
            <p>Reward: ${gameState.operations.hackSystem.baseReward.data} Data, ${gameState.operations.hackSystem.baseReward.reputation} Reputation</p>
            <p>Risk: ${Math.abs(gameState.operations.hackSystem.basePenalty.reputation)} Reputation</p>
            <div id="hackSystem-cooldown" class="cooldown" style="display: none;">Cooldown: 0s</div>
            <button onclick="hackSystem()">Execute Hack</button>
        `;
        operationsContainer.appendChild(hackSystemElement);
    }
    
    // Quantum Hacking operation
    if (gameState.operations.quantumHacking.unlocked) {
        const quantumHackElement = document.createElement('div');
        quantumHackElement.className = 'operation-item';
        quantumHackElement.innerHTML = `
            <h3>Quantum Hacking</h3>
            <p>Success Rate: ${(gameState.operations.quantumHacking.baseSuccessRate * 100).toFixed(0)}%</p>
            <p>Reward: ${gameState.operations.quantumHacking.baseReward.data} Data, ${gameState.operations.quantumHacking.baseReward.energy} Energy, ${gameState.operations.quantumHacking.baseReward.reputation} Reputation</p>
            <p>Risk: ${Math.abs(gameState.operations.quantumHacking.basePenalty.energy)} Energy, ${Math.abs(gameState.operations.quantumHacking.basePenalty.reputation)} Reputation</p>
            <div id="quantumHacking-cooldown" class="cooldown" style="display: none;">Cooldown: 0s</div>
            <button onclick="quantumHack()">Execute Quantum Hack</button>
        `;
        operationsContainer.appendChild(quantumHackElement);
    }
}

function updateAchievementsDisplay() {
    const achievementsContainer = document.getElementById('achievements-list');
    if (!achievementsContainer) return;
    
    achievementsContainer.innerHTML = '';
    
    for (const [achievementId, achievement] of Object.entries(gameState.progression.achievements)) {
        if (achievement.unlocked) {
            const achievementElement = document.createElement('div');
            achievementElement.className = 'achievement-item';
            achievementElement.innerHTML = `
                <h3>${achievement.name}</h3>
                <p>${achievement.description}</p>
            `;
            achievementsContainer.appendChild(achievementElement);
        }
    }
}

// Tab switching
function switchTab(tabId) {
    // Hide all tab content
    const tabContents = document.getElementsByClassName('tab-content');
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = 'none';
    }
    
    // Deactivate all tabs
    const tabs = document.getElementsByClassName('tab');
    for (let i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
    }
    
    // Show selected tab content and activate tab
    const selectedTab = document.getElementById(tabId);
    if (selectedTab) {
        selectedTab.style.display = 'block';
    }
    
    const selectedTabButton = document.querySelector(`.tab[data-tab="${tabId}"]`);
    if (selectedTabButton) {
        selectedTabButton.classList.add('active');
    }
    
    // Always hide achievements section when switching tabs
    const achievementsSection = document.getElementById('achievements-section');
    if (achievementsSection) {
        achievementsSection.style.display = 'none';
    }
    
    return true; // For testing purposes
}

// Show/hide achievements section
function toggleAchievements() {
    const achievementsSection = document.getElementById('achievements-section');
    if (achievementsSection.style.display === 'none' || !achievementsSection.style.display) {
        achievementsSection.style.display = 'block';
        updateAchievementsDisplay();
    } else {
        achievementsSection.style.display = 'none';
    }
    return true; // For testing purposes
}

// Log messages
function addLogMessage(message) {
    const logContainer = document.getElementById('log-container');
    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';
    
    const timestamp = new Date().toLocaleTimeString();
    logEntry.innerHTML = `<span class="log-time">[${timestamp}]</span> ${message}`;
    
    logContainer.appendChild(logEntry);
    logContainer.scrollTop = logContainer.scrollHeight;
    
    return true; // For testing purposes
}

// Modal functions
function showModal(title, content) {
    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalContent = document.getElementById('modal-content');
    
    modalTitle.textContent = title;
    modalContent.innerHTML = content;
    
    modal.style.display = 'flex';
    
    return true; // For testing purposes
}

function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
}

// Save and load game
function saveGame() {
    const saveData = JSON.stringify(gameState);
    localStorage.setItem('cyberpunkIdleGame', saveData);
    gameState.settings.lastSaveTime = Date.now();
    console.log("Game saved.");
    return true; // For testing purposes
}

function loadGame() {
    const saveData = localStorage.getItem('cyberpunkIdleGame');
    if (saveData) {
        const loadedState = JSON.parse(saveData);
        
        // Merge loaded state with default state to ensure all properties exist
        mergeGameState(gameState, loadedState);
        
        console.log("Game loaded from save.");
        return true;
    }
    return false;
}

function mergeGameState(target, source) {
    for (const key in source) {
        if (source.hasOwnProperty(key)) {
            if (typeof source[key] === 'object' && source[key] !== null && !Array.isArray(source[key])) {
                // If property doesn't exist in target, create it
                if (!target[key] || typeof target[key] !== 'object') {
                    target[key] = {};
                }
                // Recursively merge nested objects
                mergeGameState(target[key], source[key]);
            } else {
                // For non-objects, simply copy the value
                target[key] = source[key];
            }
        }
    }
}

function resetGame() {
    if (confirm("Are you sure you want to reset the game? All progress will be lost.")) {
        localStorage.removeItem('cyberpunkIdleGame');
        location.reload();
    }
}

// Helper functions
function formatId(id) {
    return id
        .replace(/([A-Z])/g, ' $1') // Add space before capital letters
        .replace(/^./, str => str.toUpperCase()); // Capitalize first letter
}

// For testing purposes
function setTestValue(key, value) {
    gameState.test = { key, value };
    return true;
}

function getTestValue() {
    return gameState.test;
}

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', initGame);

// Make functions available for testing
window.mineCredits = mineCredits;
window.collectData = collectData;
window.generateEnergy = generateEnergy;
window.hackSystem = hackSystem;
window.quantumHack = quantumHack;
window.buyUpgrade = buyUpgrade;
window.conductResearch = conductResearch;
window.unlockDistrict = unlockDistrict;
window.activateDistrict = activateDistrict;
window.switchTab = switchTab;
window.toggleAchievements = toggleAchievements;
window.addLogMessage = addLogMessage;
window.showModal = showModal;
window.closeModal = closeModal;
window.saveGame = saveGame;
window.loadGame = loadGame;
window.resetGame = resetGame;
window.setTestValue = setTestValue;
window.getTestValue = getTestValue;
window.updateResources = updateResources;
window.createTestParticles = function(elementId, text, className) {
    if (typeof createParticles === 'function') {
        return createParticles(elementId, text, className);
    }
    return true;
};
